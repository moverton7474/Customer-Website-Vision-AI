-- Visionary CMS Database Schema
-- Run this in your Supabase SQL Editor

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Create enum types
CREATE TYPE user_role AS ENUM ('admin', 'editor');
CREATE TYPE page_status AS ENUM ('draft', 'published', 'archived');

-- Users table (extends Supabase auth.users)
CREATE TABLE public.users (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email TEXT NOT NULL,
  full_name TEXT,
  role user_role NOT NULL DEFAULT 'editor',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Pages table
CREATE TABLE public.pages (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  slug TEXT NOT NULL UNIQUE,
  title TEXT NOT NULL,
  meta_description TEXT,
  og_image TEXT,
  status page_status NOT NULL DEFAULT 'draft',
  content JSONB NOT NULL DEFAULT '[]'::jsonb,
  created_by UUID NOT NULL REFERENCES public.users(id),
  updated_by UUID NOT NULL REFERENCES public.users(id),
  published_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Create indexes for better query performance
CREATE INDEX idx_pages_slug ON public.pages(slug);
CREATE INDEX idx_pages_status ON public.pages(status);
CREATE INDEX idx_pages_created_by ON public.pages(created_by);
CREATE INDEX idx_pages_updated_at ON public.pages(updated_at DESC);

-- Enable Row Level Security
ALTER TABLE public.users ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.pages ENABLE ROW LEVEL SECURITY;

-- Users RLS Policies
-- Users can read their own profile
CREATE POLICY "Users can view own profile" ON public.users
  FOR SELECT USING (auth.uid() = id);

-- Admins can view all users
CREATE POLICY "Admins can view all users" ON public.users
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM public.users 
      WHERE id = auth.uid() AND role = 'admin'
    )
  );

-- Admins can update users
CREATE POLICY "Admins can update users" ON public.users
  FOR UPDATE USING (
    EXISTS (
      SELECT 1 FROM public.users 
      WHERE id = auth.uid() AND role = 'admin'
    )
  );

-- Pages RLS Policies
-- Anyone can read published pages (for public site)
CREATE POLICY "Anyone can view published pages" ON public.pages
  FOR SELECT USING (status = 'published');

-- Authenticated users can view all pages (for admin)
CREATE POLICY "Authenticated users can view all pages" ON public.pages
  FOR SELECT USING (auth.role() = 'authenticated');

-- Authenticated users can insert pages
CREATE POLICY "Authenticated users can create pages" ON public.pages
  FOR INSERT WITH CHECK (auth.role() = 'authenticated');

-- Authenticated users can update pages
CREATE POLICY "Authenticated users can update pages" ON public.pages
  FOR UPDATE USING (auth.role() = 'authenticated');

-- Only admins can delete pages
CREATE POLICY "Admins can delete pages" ON public.pages
  FOR DELETE USING (
    EXISTS (
      SELECT 1 FROM public.users 
      WHERE id = auth.uid() AND role = 'admin'
    )
  );

-- Function to auto-update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Triggers for updated_at
CREATE TRIGGER update_users_updated_at
  BEFORE UPDATE ON public.users
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_pages_updated_at
  BEFORE UPDATE ON public.pages
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- Function to create user profile on signup
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO public.users (id, email, full_name, role)
  VALUES (
    NEW.id,
    NEW.email,
    NEW.raw_user_meta_data->>'full_name',
    'editor'
  );
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Trigger to auto-create profile on signup
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_new_user();

-- Storage bucket for uploads (optional)
-- Run this separately if you want file upload support
-- INSERT INTO storage.buckets (id, name, public) VALUES ('cms-uploads', 'cms-uploads', true);

-- Storage policies for uploads bucket
-- CREATE POLICY "Authenticated users can upload" ON storage.objects
--   FOR INSERT WITH CHECK (
--     bucket_id = 'cms-uploads' AND auth.role() = 'authenticated'
--   );

-- CREATE POLICY "Anyone can view uploads" ON storage.objects
--   FOR SELECT USING (bucket_id = 'cms-uploads');

-- CREATE POLICY "Authenticated users can update their uploads" ON storage.objects
--   FOR UPDATE USING (
--     bucket_id = 'cms-uploads' AND auth.role() = 'authenticated'
--   );

-- CREATE POLICY "Authenticated users can delete their uploads" ON storage.objects
--   FOR DELETE USING (
--     bucket_id = 'cms-uploads' AND auth.role() = 'authenticated'
--   );

-- =================================================================
-- INITIAL SETUP: Create your first admin user
-- =================================================================
-- After running the schema above:
-- 1. Go to Supabase Auth > Users > Invite user
-- 2. Enter your email and set a password
-- 3. Then run this query to make yourself an admin:
-- 
-- UPDATE public.users 
-- SET role = 'admin' 
-- WHERE email = 'your-email@example.com';
-- =================================================================
